import React, { Component } from 'react';

class Subcontent extends Component {
  render() { 
    return (
      <div className="Subcontent"></div>
    );
  }
}

export default Subcontent;