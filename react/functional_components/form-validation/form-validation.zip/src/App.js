import './App.css';
import ValidatedForm from './components/ValidatedForm';

function App() {
  return (
    <div className="App">
      <ValidatedForm/>
    </div>
  );
}

export default App;
