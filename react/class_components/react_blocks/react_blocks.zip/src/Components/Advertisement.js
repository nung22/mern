import React, { Component } from 'react';

class Advertisement extends Component {
  render() { 
    return (
      <div className="Advertisement"></div>
    );
  }
}

export default Advertisement;