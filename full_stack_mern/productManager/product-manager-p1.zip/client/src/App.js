import React from 'react';
import Main from './views/Main';
function App() {
  return (
    <div className="App p-8 flex justify-center">
      <Main />
    </div>
  );
}
export default App;

